class Process:
    def __init__(self, pid, burst_time, priority=0):
        self.pid = pid
        self.burst_time = burst_time
        self.priority = priority
        self.wait_time = 0
        self.turnaround_time = 0

def fcfs(processes):
    print("\n--- FCFS Scheduling ---")
    current_time = 0
    total_wait = 0
    for p in processes:
        p.wait_time = current_time
        p.turnaround_time = p.wait_time + p.burst_time
        current_time += p.burst_time
        total_wait += p.wait_time
        print(f"Process {p.pid}: Wait={p.wait_time}, Turnaround={p.turnaround_time}")
    print(f"Avg Wait Time: {total_wait / len(processes)}")

def sjf(processes):
    print("\n--- SJF Scheduling (Non-Preemptive) ---")
    # Sort by burst time
    sorted_p = sorted(processes, key=lambda x: x.burst_time)
    fcfs(sorted_p) # Logic is same as FCFS once sorted

def round_robin(processes, quantum):
    print(f"\n--- Round Robin Scheduling (Quantum={quantum}) ---")
    n = len(processes)
    remaining_burstTime = [p.burst_time for p in processes] # Store remaining burst times
    t = 0 # Current time
    
    while True:
        done = True
        for i in range(n):
            if remaining_burstTime[i] > 0:
                done = False 
                
                if remaining_burstTime[i] > quantum:
                    t += quantum
                    remaining_burstTime[i] -= quantum
                else:
                    t += remaining_burstTime[i]
                    # Arrival time is assumed 0 for all
                    processes[i].turnaround_time = t
                    processes[i].wait_time = t - processes[i].burst_time
                    remaining_burstTime[i] = 0
                    print(f"Process {processes[i].pid}: Wait={processes[i].wait_time}, Turnaround={processes[i].turnaround_time}")
        if done:
            break

# Example Usage
if __name__ == "__main__":
    # Define processes: ID, Burst Time
    procs = [Process(1, 10), Process(2, 5), Process(3, 8)]
    fcfs(list(procs)) 
    
    # Re-create list for fresh run
    procs = [Process(1, 10), Process(2, 5), Process(3, 8)]
    sjf(list(procs))

    procs = [Process(1, 10), Process(2, 5), Process(3, 8)]
    round_robin(list(procs), quantum=2)