import threading
def thread_function(name):
    print(f"Thread {name} is running")
threads = []
for i in range(1, 3):
    t = threading.Thread(target=thread_function, args=(i,))
    threads.append(t)
    t.start()
for t in threads:
    t.join()
print("Main thread finished")
