import socket

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address = ('localhost', 9999)
message = b'This is the message. It will be echoed back.'

try:
    print(f"Sending: {message.decode()}")
    client.sendto(message, server_address)

    # Wait for response
    # recvfrom is preferred over recv for UDP so you know who sent it
    data, server = client.recvfrom(1024)
    print(f"Received from server: {data.decode()}")

finally:
    client.close()