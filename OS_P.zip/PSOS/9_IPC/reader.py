from multiprocessing import shared_memory
shm = shared_memory.SharedMemory(name="ipc_demo")
data = bytes(shm.buf[:50]).decode("utf-8").rstrip("\x00")
print("Reader read:", data)
shm.close()
