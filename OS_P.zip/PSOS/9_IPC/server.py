import socket

# Create a UDP socket
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind(('localhost', 9999))

print("UDP server is running on port 9999...")

while True:
    # UDP uses recvfrom() instead of accept() + recv()
    # It returns the data AND the address of the sender instantly
    data, addr = server.recvfrom(1024)
    
    print(f"Received message from {addr}")
    
    if data:
        response = f"Echo: {data.decode()}".encode()
        # UDP uses sendto() because there is no permanent 'conn' object
        server.sendto(response, addr)